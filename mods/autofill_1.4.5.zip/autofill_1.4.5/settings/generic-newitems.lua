--
-- Disclaimer: mp warranty void if edited.
--

return {
["combat-units"] = {"destroyer-unit-ammo", "defender-unit-ammo", "distractor-unit-ammo"}, --Combat Units
["mo-ammo-goliath"] = {"mega-cannon-shell"} --MoMods
}
