
return {
  ["gunship"] = { slots={2,1,1}, "fuels-all", "ammo-bullets", "ammo-rockets" },
  ["cargo-plane"] = { slots={6,1,1}, "fuels-all", "ammo-bullets" },
  ["jet"] = { slots={3,1,1}, "fuels-all", "ammo-bullets", "ammo-rockets" },
  ["flying-fortress"] = { slots={4,1,1}, "fuels-all", "ammo-bullets", "ammo-shells" },
}
