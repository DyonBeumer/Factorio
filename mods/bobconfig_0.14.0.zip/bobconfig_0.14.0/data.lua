if not bobmods then bobmods = {} end
if not bobmods.config then bobmods.config = {} end

if not bobmods.config.enemies then bobmods.config.enemies = {} end
if not bobmods.config.logistics then bobmods.config.logistics = {} end
if not bobmods.config.mining then bobmods.config.mining = {} end
if not bobmods.config.modules then bobmods.config.modules = {} end
if not bobmods.config.ores then bobmods.config.ores = {} end
if not bobmods.config.gems then bobmods.config.gems = {} end
if not bobmods.config.plates then bobmods.config.plates = {} end
if not bobmods.config.warfare then bobmods.config.warfare = {} end
if not bobmods.config.power then bobmods.config.power = {} end
if not bobmods.config.assembly then bobmods.config.assembly = {} end


require("config")

require("overide")

