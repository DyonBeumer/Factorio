--[[

!! IMPORTANT !!
Make a copy of the file and rename it to [_custom_.lua] before edit.
To enable custom changes - set "use_custom_order" in config.lua to "true"


You can use all of existed in this mod functions (lib/util.lua).
But in almost 90% of cases you can do all you want just using three of them:

aadd(group, item, order)	-- Place (or show recently hided) item and/or recipe to another group.
ahide(item, replace_by)		-- Hide item and recipe, also remove recipe from technology.
switch_tech(technology)		-- Switch off technology (hiding from research tree).

There is two modification of aadd and ahide functions:

iadd(group, item, order)	-- Place (or show recently hided) only item (ignore recipe) to another group.
radd(group, item, order)	-- Place (or show recently hided) only recipe (ignore item) to another group.

ihide(item, replace_by)		-- Hide only item (recipe will stay available).
rhide(item, replace_by)		-- Hide only recipe (item will stay available), also remove recipe from technology.


Also you can use boolean functions to check existence of item:

i_exist(item)		-- Return "true" if item exist, "false" otherwise.
i_not_exist(item)	-- Return "true" if item NOT exist, "false" otherwise.

In all cases when your changes affect existing technology tree - you must start new game to take effects.

Also you must to know: internal item name is not the same what you see in game !!
There is a easiest way to find that name - go to mod directory of items which you want to rearrange and rename "local" folder and restart the game.
After that you should see internal items names, like "item_name.raw-wood" or similar. Name is the part which after last dot ("raw-wood" for example).
Then, when you are done - just rename it back to "local" and restart again.

]]
do -- Arumba's Changes:
	--GROUP NAME--			-- ITEM --									 --ORDER--
-- move intermediate wires to intermediates
aadd("z-intermediate-0",	"copper-cable",									"a")
aadd("z-intermediate-0",	"tinned-copper-cable",							"b")
aadd("z-intermediate-0",	"insulated-cable",								"c")
aadd("z-intermediate-0",	"gilded-copper-cable",							"d")
-- move module case to modules category and organize
aadd("z-module-1",	"module-case",											"a")
aadd("z-module-1",	"module-contact",										"b")
aadd("z-module-1",	"module-circuit-board",									"c")
aadd("z-module-2",	"module-processor-board",								"a")
aadd("z-module-2",	"module-processor-board-2",								"a")
aadd("z-module-2",	"module-processor-board-3",								"a")
aadd("z-module-2",	"speed-processor",										"b")
aadd("z-module-2",	"speed-processor-2",									"b")
aadd("z-module-2",	"speed-processor-3",									"b")
aadd("z-module-2",	"effectivity-processor",								"c")
aadd("z-module-2",	"effectivity-processor-2",								"c")
aadd("z-module-2",	"effectivity-processor-3",								"c")
aadd("z-module-3",	"productivity-processor",								"a")
aadd("z-module-3",	"productivity-processor-2",								"a")
aadd("z-module-3",	"productivity-processor-3",								"a")
aadd("z-module-3",	"pollution-clean-processor",							"b")
aadd("z-module-3",	"pollution-clean-processor-2",							"b")
aadd("z-module-3",	"pollution-clean-processor-3",							"b")
aadd("z-module-3",	"pollution-create-processor",							"c")
aadd("z-module-3",	"pollution-create-processor-2",							"c")
aadd("z-module-3",	"pollution-create-processor-3",							"c")
-- adjust intermediates category
aadd("z-intermediate-2",	"wooden-board",									"a")
aadd("z-intermediate-2",	"phenolic-board",								"b")
aadd("z-intermediate-2",	"circuit-board",								"c")
aadd("z-intermediate-2",	"superior-circuit-board",						"d")
aadd("z-intermediate-2",	"fibreglass-board",								"e")
aadd("z-intermediate-2",	"multi-layer-circuit-board",					"f")
aadd("z-intermediate-3",	"basic-electronic-components",					"a")
aadd("z-intermediate-3",	"electronic-components",						"b")
aadd("z-intermediate-3",	"intergrated-electronics",						"c")
aadd("z-intermediate-3",	"processing-electronics",						"d")
aadd("z-intermediate-3",	"solder",										"e")
aadd("z-intermediate-3",	"solder-alloy-lead",							"f")
aadd("z-intermediate-3",	"solder-alloy",									"g")

-- mining drills
aadd("z-gathering-4",	"electric-mining-drill",							"a")
aadd("z-gathering-4",	"bob-mining-drill-1",								"b")
aadd("z-gathering-4",	"bob-mining-drill-2",								"b")
aadd("z-gathering-4",	"bob-mining-drill-3",								"b")
aadd("z-gathering-4",	"bob-mining-drill-4",								"b")
-- furnaces
aadd("z-production-0",	"chemical-boiler",									"c")
aadd("z-production-0",	"mixing-furnace",									"d")
aadd("z-production-1",	"chemical-furnace",									"a")
aadd("z-production-1",	"electric-mixing-furnace",							"b")
aadd("z-production-2",	"electric-furnace",									"a")
aadd("z-production-2",	"electric-furnace-2",								"b")
aadd("z-production-2",	"electric-furnace-3",								"b")
aadd("z-production-3",	"electric-chemical-mixing-furnace",					"a")
aadd("z-production-3",	"electric-chemical-mixing-furnace-2",				"a")
-- coal, carbon and solid fuel
aadd("z-resources-1",	"coal",												"a")
aadd("z-resources-1",	"carbon",											"b")
aadd("z-resources-1",	"solid-fuel",										"c")
-- inserters
aadd("z-automatization-1",	"inserter",										"a")
aadd("z-automatization-1",	"fast-inserter",								"b")
aadd("z-automatization-1",	"express-inserter",								"c")
aadd("z-automatization-1",	"stack-inserter",								"d")
aadd("z-automatization-1",	"express-stack-inserter",						"e")
aadd("z-automatization-2",	"filter-inserter",								"a")
aadd("z-automatization-2",	"express-filter-inserter",						"b")
aadd("z-automatization-2",	"stack-filter-inserter",						"c")
aadd("z-automatization-2",	"express-stack-filter-inserter",				"d")
-- energy tab
aadd("z-energy-0",	"boiler",												"a")
aadd("z-energy-0",	"boiler-2",												"a")
aadd("z-energy-0",	"boiler-3",												"a")
aadd("z-energy-0",	"boiler-4",												"a")
aadd("z-energy-1",	"steam-engine",											"a")
aadd("z-energy-1",	"steam-engine-2",										"a")
aadd("z-energy-1",	"steam-engine-3",										"a")
aadd("z-energy-2",	"solar-panel-small",									"a")
aadd("z-energy-2",	"solar-panel-small-2",									"a")
aadd("z-energy-2",	"solar-panel-small-3",									"a")
aadd("z-energy-3",	"solar-panel",											"a")
aadd("z-energy-3",	"solar-panel-2",										"a")
aadd("z-energy-3",	"solar-panel-3",										"a")
aadd("z-energy-4",	"solar-panel-large",									"a")
aadd("z-energy-4",	"solar-panel-large-2",									"a")
aadd("z-energy-4",	"solar-panel-large-3",									"a")
aadd("z-energy-5",	"accumulator",											"a")
aadd("z-energy-5",	"large-accumulator",									"b")
aadd("z-energy-5",	"large-accumulator-2",									"c")
aadd("z-energy-5",	"large-accumulator-3",									"c")
aadd("z-energy-6",	"slow-accumulator",										"a")
aadd("z-energy-6",	"slow-accumulator-2",									"a")
aadd("z-energy-6",	"slow-accumulator-3",									"a")
aadd("z-energy-7",	"fast-accumulator",										"a")
aadd("z-energy-7",	"fast-accumulator-2",									"a")
aadd("z-energy-7",	"fast-accumulator-3",									"a")
aadd("z-energy-8",	"small-electric-pole",									"a")
aadd("z-energy-8",	"medium-electric-pole",									"b")
aadd("z-energy-8",	"medium-electric-pole-2",								"b")
aadd("z-energy-8",	"medium-electric-pole-3",								"b")
aadd("z-energy-8",	"medium-electric-pole-4",								"b")
aadd("z-energy-9",	"big-electric-pole",									"a")
aadd("z-energy-9",	"big-electric-pole-2",									"a")
aadd("z-energy-9",	"big-electric-pole-3",									"a")
aadd("z-energy-9",	"big-electric-pole-4",									"a")
aadd("z-energy-10",	"substation",											"a")
aadd("z-energy-10",	"substation-2",											"a")
aadd("z-energy-10",	"substation-3",											"a")
aadd("z-energy-10",	"substation-4",											"a")
-- move science packs to alien production
aadd("z-alien-0",	"science-pack-1",										"a")
aadd("z-alien-0",	"science-pack-2",										"a")
aadd("z-alien-0",	"science-pack-3",										"a")
aadd("z-alien-0",	"science-pack-4",										"a")
aadd("z-alien-0",	"alien-science-pack",									"b")
aadd("z-alien-0",	"science-pack-gold",									"c")
-- launch control into defense
aadd("z-defense-9",	"launch-control-center",								"a")
-- organize trains and wagons
aadd("z-vehicles-0",	"diesel-locomotive",								"a")
aadd("z-vehicles-0",	"bob-diesel-locomotive-2",							"b")
aadd("z-vehicles-0",	"bob-diesel-locomotive-3",							"b")
aadd("z-vehicles-0",	"bob-armoured-diesel-locomotive",					"c")
aadd("z-vehicles-1",	"cargo-wagon",										"a")
aadd("z-vehicles-1",	"bob-cargo-wagon-2",								"b")
aadd("z-vehicles-1",	"bob-cargo-wagon-3",								"b")
aadd("z-vehicles-1",	"bob-armoured-cargo-wagon",							"c")
aadd("z-vehicles-2",	"farl",												"a")
aadd("z-vehicles-2",	"rail-tanker",										"b")
aadd("z-vehicles-3",	"car",												"a")
aadd("z-vehicles-3",	"tank",												"a")
aadd("z-vehicles-3",	"bob-tank-2",										"b")
aadd("z-vehicles-3",	"bob-tank-3",										"b")
aadd("z-vehicles-3",	"bob-robot-tank",									"c")
-- move tank shells to weaponry
aadd("z-weaponry-10",	"cannon-shell",										"a")
aadd("z-weaponry-10",	"explosive-cannon-shell",							"b")
aadd("z-weaponry-10",	"scatter-cannon-shell",								"c")
aadd("z-weaponry-10",	"poison-artillery-shell",							"d")
aadd("z-weaponry-10",	"explosive-artillery-shell",						"e")
aadd("z-weaponry-10",	"distractor-artillery-shell",						"f")
-- fix the sulfur processing from bobs mods
aadd("z-liquids-1",		"basic-oil-processing",								"a")
aadd("z-liquids-1",		"crude-oil-processing",								"b")
aadd("z-liquids-1",		"advanced-oil-processing",							"c")
aadd("z-liquids-2",		"oil-processing-with-sulfur",						"a")
aadd("z-liquids-2",		"oil-processing-with-sulfur-dioxide",				"b")
aadd("z-liquids-2",		"oil-processing-with-sulfur-dioxide-2",				"b")
aadd("z-liquids-2",		"oil-processing-with-sulfur-dioxide-3",				"b")

end
--[[ EXAMPLE #1

		--GROUP NAME--	-- ITEM --	 --ORDER--
	aadd("z-other-4",	"raw-wood",		"a")	-- Regroup item
	aadd("z-other-4",	"coal",			"b")	-- Regroup item

]]
--[[ EXAMPLE #2

	if i_exist("bi_bio_farm") then			-- If [Bio Farm] from "Bio Industries" mod exist?
	
			-- GROUP NAME --		  -- ITEM --	 	 --ORDER--
		aadd("z-production-9",		"bi_bio_farm",			"a")
		aadd("z-production-9",		"bi-Bio_Garden",		"b")
		aadd("z-production-9",		"bi-cokery",			"c")
		aadd("z-production-9",		"bi-bioreactor",		"d")
		aadd("z-production-9",		"bi-stone-crusher",		"e")
	
		rhide("bob-seedling")					-- Hide Bob's version recipe of seedling
		ahide("bob-fertiliser")					-- Hide item and recipe.
		
		switch_tech("bob-fertiliser")			-- Hide technology.
	end

]]
--[[ List of inventory groups (mask: z-[name]-[0..n])  [
	z-gathering-#
	z-production-#
	z-resources-#
	z-plates-#
	z-liquids-#
	z-chemistry-#
	z-automatization-#
	z-transport-#
	z-logistic-#
	z-energy-#
	z-module-#
	z-defense-#
	z-intermediate-#
	z-parts-#
	z-youki-#
	z-armor-#
	z-weaponry-#
	z-trains-#
	z-vehicles-#
	z-alien-#
	z-refining-#
	z-atom-#
	z-decorative-#
	z-other-#
] ]]