require("prototypes.recipe.alternate-alien-science-recipes")
require("prototypes.technology.alternate-alien-science-technologies")