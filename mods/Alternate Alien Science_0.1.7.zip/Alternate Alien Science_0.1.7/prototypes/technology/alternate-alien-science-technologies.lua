data:extend(
{
  {
    type = "technology",
    name = "alternate-alien-science-creation",
    icon = "__Alternate Alien Science__/graphics/technology/alternate-alien-science-pack.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "alternate-alien-science-recipe"
      }
    },
    prerequisites = {"alien-technology","explosive-rocketry","stack-inserter","robotics"},
    unit =
    {
      count = 150,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 20
    },
    order = "e-f-a"
  },
  {
    type = "technology",
    name = "alternate-alien-artifact-creation",
    icon = "__Alternate Alien Science__/graphics/technology/alternate-alien-artifact.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "alternate-alien-artifact-recipe"
      }
    },
    prerequisites = {"alternate-alien-science-creation"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"alien-science-pack", 1}
      },
      time = 20
    },
    order = "e-f-a"
  },
})