data:extend(
{
	{
		type = "recipe",
		name = "alternate-alien-science-recipe",
		energy_required = "30",
		enabled = "false",
		ingredients = {
			{"flying-robot-frame", 1},
			{"processing-unit", 1},
			{"stack-filter-inserter", 1},
			{"explosive-rocket", 3},
		},
		result = "alien-science-pack"
	},
	{
		type = "recipe",
		name = "alternate-alien-artifact-recipe",
		energy_required = "30",
		enabled = "false",
		ingredients = {
			{"alien-science-pack", 10},
			{"repair-pack", 10}
		},
		result = "alien-artifact"
	}
})